package fr.thomas.lefebvre.ordomanager.activity

import android.annotation.SuppressLint
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.View
import fr.thomas.lefebvre.ordomanager.R
import kotlinx.android.synthetic.main.activity_list_ordo.*

class ListOrdoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_ordo)
       setToolBarListOrdo()

    }


    fun setToolBarListOrdo(){
        toolbar.setTitle("")
        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener(View.OnClickListener {
            super.onBackPressed()
        })

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_list_ordo,menu)
        return super.onCreateOptionsMenu(menu)
    }
}
