package fr.thomas.lefebvre.ordomanager.activity

import android.app.DatePickerDialog
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.view.Menu
import android.view.View
import android.widget.Toast
import fr.thomas.lefebvre.ordomanager.R
import kotlinx.android.synthetic.main.activity_list_ordo.*
import kotlinx.android.synthetic.main.activity_new_ordo.*
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*

class NewOrdoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_ordo)
        setToolBarNewOrdo()
    }

    fun setToolBarNewOrdo(){
        toolbar2.setTitle("")
        setSupportActionBar(toolbar2)
        toolbar2.setNavigationOnClickListener(View.OnClickListener {
            super.onBackPressed()
        })
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_new_ordo,menu)
        return super.onCreateOptionsMenu(menu)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun clickDataPicker(view:View){
        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)

        val dpd = DatePickerDialog(this, DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
            // Display Selected date in Toast
            var dayString:String
            if(dayOfMonth<10){
                dayString="0$dayOfMonth"
            }
            else dayString="$dayOfMonth"

            var monthString:String
                    if((monthOfYear+1)<10){
                         monthString="0${monthOfYear+1}"
            }
                    else monthString="${monthOfYear+1}"

            var yearString:String="$year"

            var format=DateTimeFormatter.ofPattern("dd-MM-yyyy")
            var date=LocalDate.parse(yearString+"-"+monthString+"-"+dayString)
            var dateFormat=date.format(format)
            tv_show_date_debut.text=dateFormat

        }, year, month, day)
        dpd.show()
    }

}
